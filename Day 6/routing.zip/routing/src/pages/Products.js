function ProductsPage(){
    return <h1>The Products page</h1>
}
export default ProductsPage;