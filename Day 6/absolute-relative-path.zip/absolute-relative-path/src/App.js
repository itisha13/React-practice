import { createBrowserRouter, RouterProvider } from "react-router-dom";
import ErrorPage from "./pages/Error";
//import { createRoutesFromElements, Route } from "react-router-dom";
import HomePage from "./pages/Home";
import ProductDetailPage from "./pages/ProductDetails";
import ProductsPage from "./pages/Products";
import RootLayout from "./pages/Root";

//ALTERNATE WAY
// const routeDefinitions = createRoutesFromElements(
//   <Route>
//     <Route path="/" element={<HomePage/>}></Route>
//     <Route path="/products" element={<ProductsPage/>}></Route>
//   </Route>
// );
// const router = createBrowserRouter(routeDefinitions);


const router = createBrowserRouter([
  {
    path: '/', 
    element: <RootLayout />,
    errorElement : <ErrorPage/>,
    children: [
      // { path: '', element: <HomePage /> }, //relative path
      { index: true, element: <HomePage /> }, //its the default route (same as root "/")
      { path: 'products', element: <ProductsPage /> },
      {path: 'products/:productId', element:<ProductDetailPage/>}
    ]
  },

]);

function App() {
  return <RouterProvider router={router} />;
}

export default App;
