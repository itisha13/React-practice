import { useParams, Link } from "react-router-dom";

function ProductDetailPage(){
    const params = useParams();

    return (
        <>
            <h1>Product Details</h1>
            <p>{params.productId}</p>
            <p><Link to=".." relative="path">Back</Link></p>
            {/* if relative="route", would have gone to its parent comp which is home page (see route in App.js) */}
        </>
    )
}
export default ProductDetailPage;