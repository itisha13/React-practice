// import ApplyForm from '../Apply-form/ApplyForm';
import classes from './Jobs.module.css';
// import { useState, useEffect } from 'react';
// import { Router, Link } from 'react-router-dom';
import { Link } from 'react-router-dom';
export default function Jobs({ jobList, isLoading, loadingText, fallbackText }) {

    // const [jobs, setJobs] = useState([]);

    // useEffect(() => {
    //     async function fetchJobs(){
    //         const response = await fetch('https://www.themuse.com/api/public/jobs?category=Accounting&category=Data%20and%20Analytics&category=HR&category=Project%20Management&category=Sales&category=Software%20Engineer&location=Bangalore%2C%20India&location=Gurgaon%2C%20India&location=Hyderabad%2C%20India&location=London%2C%20United%20Kingdom&location=New%20Delhi%2C%20India&location=Pune%2C%20India&location=Vancouver%2C%20Canada&page=2');
    //         const resData = await response.json();
    //         setJobs(resData.results)
    //     }
    //     fetchJobs();
    // }, []);

    // function applyHandler(){

    // }



    return (
        <>
            {isLoading && <p className={classes.fallback}>{loadingText}</p>}
            {!isLoading && jobList.length === 0 && <p className={classes.fallback}>{fallbackText}</p>}
            {!isLoading && jobList.length > 0 && (
                <div>
                    {jobList.map((job) => (
                        <div className={classes.outline}>

                            <table className={classes.tbl}>
                                <tr>
                                    <td className={classes.firstcol}>
                                        <p style={{ fontSize: 'small' }}><strong>{job.id}</strong></p>
                                        <p>{job.name}</p>
                                        <span>{job.company.name}</span>
                                    </td>
                                    <td className={classes.midcol}>
                                        <p>{job.categories[0].name}</p>
                                        <p style={{ fontSize: 'small' }}>{job.levels[0].name}</p>
                                    </td>
                                    <td className={classes.lastcol}>
                                        <p class={classes.lasttop}>{job.publication_date.slice(0, 10)} | location</p>
                                        {/* <button className={classes.chkbtn} onClick={applyHandler}> Check</button> */}
                                        <Link to={`/apply/${job.id}/${job.categories[0].name}/${job.company.name}`}><button className={classes.chkbtn}> Apply</button></Link>
                                        

                                    </td>
                                </tr>
                            </table>


                        </div>
                    ))}
                    {/* <ApplyForm/> */}
                </div>
            )}

            {/* {jobList.map((job) => (
                <div className={classes.outline}>

                    <table className={classes.tbl}>
                        <tr>
                            <td className={classes.firstcol}>
                                <p style={{ fontSize: 'small' }}><strong>{job.id}</strong></p>
                                <p>{job.name}</p>
                                <span>{job.company.name}</span>
                            </td>
                            <td className={classes.midcol}>
                                <p>{job.categories[0].name}</p>
                                <p style={{ fontSize: 'small' }}>{job.levels[0].name}</p>
                            </td>
                            <td className={classes.lastcol}>
                                <p class={classes.lasttop}>{job.publication_date.slice(0, 10)} | location</p>
                                <button className={classes.chkbtn}> Check</button>

                            </td>
                        </tr>
                    </table>


                </div>
            ))} */}

        </>
    );
}