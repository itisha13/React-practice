// import ApplyForm from "../Apply-form/ApplyForm";
import Filterbar from "../Filter-Bar/Filterbar";
import Header from "../Header/Header";
import Jobs from "../Jobs/Jobs";
// import Jobs from "../Jobs/Jobs";

export default function HomePage() {
    return (
        <>
            <Header heading='Job Board'/>
            <Filterbar>
                <Jobs />
            </Filterbar>
        </>

    );
}