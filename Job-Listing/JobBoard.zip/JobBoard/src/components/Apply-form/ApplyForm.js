import classes from './ApplyForm.module.css';
import { useParams } from 'react-router-dom';
import { Link } from 'react-router-dom';
import Header from '../Header/Header';
import { useState } from 'react';
function ApplyForm() {
    const [isApplied, setIsApplied] = useState(false);
    const params = useParams();

    function applyHandler() {
        setIsApplied(true);
    }

    return (
        <>
            <Header heading={`Applying for Job Id : ${params.jobId} \u00A0\u00A0|\u00A0\u00A0  Role : ${params.role} \u00A0\u00A0|\u00A0\u00A0 Company : ${params.cmp}`} />
            {isApplied && (
                <div>
                    <p className={classes.fallback}>Applied Successfully!</p>
                    <Link to='/'><button className={classes.goback}> Go to Jobs Board</button></Link>
                </div>



            )}
            {!isApplied && (
                <div className={classes.outer}>
                    <form className={classes.formclass}>
                        <table>
                            <tr>
                                <td className={classes.col1}>
                                    <label for='fname'>First Name:&nbsp;</label><br />
                                    <input type='text' size='30' id='fname' name='fname' /><br /><br />
                                </td>
                                <td >
                                    <label for='lname'>Last Name:&nbsp;</label><br />
                                    <input type='text' size='30' id='lname' name='lname' /><br /><br />
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <label for="email">Enter your email:</label><br />
                                    <input type="email" size="40" id="email" name="email" /><br /><br />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <p>Choose a gender</p>
                                    <input type='radio' id='gender' name='gender' value='male' />
                                    <label for="gender">Male</label><br />
                                    <input type='radio' id='gender' name='gender' value='female' />
                                    <label for="gender">Female</label><br /><br />
                                </td>
                            </tr>

                            <tr>
                                <td className={classes.col1}>
                                    <label for='company'>Current Company Name:</label><br />
                                    <input type='text' size='30' id='company' name='company' /><br /><br />
                                </td>
                                <td >
                                    <label for='profile'>Current Profile:</label><br />
                                    <input type='text' size='30' id='profile' name='profile' /><br /><br />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label for="experience">Years of Experience:</label><br />
                                    <input type="number" id="experience" name="experience" min="0" max="10" /><br /><br />
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <label for="resume">Upload your resume&nbsp; </label><br />
                                    <input type="file" name="resume" id="resume" accept="application/pdf,application/vnd.ms-excel" /><br />
                                </td>
                            </tr>

                        </table>

                    </form>

                    <button className={classes.btn} onClick={applyHandler} type='button' value='apply'>Apply</button>

                </div>
            )}

        </>
    );
}
export default ApplyForm;