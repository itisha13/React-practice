import classes from './Header.module.css';

export default function Header({heading}) {
    return (
        <>
        <div className={classes.head}>
            {heading}
        </div>
            {/* <div className={classes.head} class='py-4 bg-dark text-light'>
                Job Board
            </div> */}
        </>
    );
}