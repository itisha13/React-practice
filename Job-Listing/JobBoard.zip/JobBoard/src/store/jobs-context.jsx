import { createContext } from "react";

export const JobsContext = createContext({
    jobslist  : []
});