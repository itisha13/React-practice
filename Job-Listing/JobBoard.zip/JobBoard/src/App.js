import './App.css';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
// import Header from './components/Header/Header';
import HomePage from './components/HomePage/HomePage';
import ApplyForm from './components/Apply-form/ApplyForm';
// import Filterbar from './components/Filter-Bar/Filterbar';
// import Jobs from './components/Jobs/Jobs';

const router = createBrowserRouter([
  {
    path:'/',
    element: <HomePage/>
  },
  {
    path:'/apply/:jobId/:role/:cmp',
    element : <ApplyForm/>
  }
])

function App() {
  return (
    <RouterProvider router={router}/>
     
    
  );
}

export default App;
