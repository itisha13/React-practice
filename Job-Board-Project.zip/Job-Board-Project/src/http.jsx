export async function fetchAllJobs() {
    const response = await fetch('http://localhost:8000/jobs');
    const resData = await response.json();
    return resData;
}

export async function addJob(job){
    const response = await fetch('http://localhost:8000/jobs',{
        method : 'POST',
        body : JSON.stringify(job),
        headers : {
            'Content-Type' : 'application/json'
        }
    });
    const resData = await response.json();
    return resData;
}

export async function deleteJob(id){
    const response = await fetch(`http://localhost:8000/jobs/${id}`,{
        method : 'DELETE',
    })
    const resData = await response.json();
    return resData;
}