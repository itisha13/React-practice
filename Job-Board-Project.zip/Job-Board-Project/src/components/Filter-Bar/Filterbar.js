import Jobs from '../Jobs/Jobs';
import classes from './Filterbar.module.css';
import { useState, useEffect, useRef } from 'react';
import {fetchAllJobs} from '../../http';

export default function Filterbar() {
    const [isFetching, setIsFetching] = useState(false);
    const [jobs, setJobs] = useState([]);
    const [defaultFilter , setDefaultFilter] = useState(true);
    const [filteredJobs , setFilteredJobs] = useState([])

    const categoryRef = useRef('Categories');
    const locationRef = useRef('Location');

    useEffect(() => {

        async function fetchJobs() {
            setIsFetching(true);
            // const response = await fetch('https://www.themuse.com/api/public/jobs?category=Accounting&category=Data%20and%20Analytics&category=HR&category=Project%20Management&category=Sales&category=Software%20Engineer&location=Bangalore%2C%20India&location=Gurgaon%2C%20India&location=Hyderabad%2C%20India&location=London%2C%20United%20Kingdom&location=New%20Delhi%2C%20India&location=Pune%2C%20India&location=Vancouver%2C%20Canada&page=2');
            // const response = await fetch('http://localhost:8000/jobs');
            // const resData = await response.json();
            const resData = await fetchAllJobs();
            setJobs(resData);
            console.log(resData);
            setIsFetching(false);
        }
        fetchJobs();
    }, []);

    function filterHandler() {
        //filter,find,findAll
        console.log("jobs" + jobs);
        let cat = categoryRef.current.value;
        let loc = locationRef.current.value;
        
        let filteredJobList = [];
        console.log(cat + " " + loc);
        if (cat === "Categories" && loc === "Location") {
            setDefaultFilter(true);
            // setJobs(jobs);
            return;
        } else if (cat === "Categories") {
            filteredJobList =  jobs.filter((job)=>{
                return job.location === loc;
            })
        } else if (loc === "Location") {
            
            filteredJobList = jobs.filter((job)=>{
                return job.category === cat;
            })
            // setJobs(jobs.map((job) => {
            //     console.log(job);
            //     return job.categories[0].name === cat;
            // }));
        } else {
            filteredJobList = jobs.filter((job)=>{
                return (job.location === loc  && job.category === cat);
            })
        }
        console.log('After'+ filteredJobs);
        setFilteredJobs(filteredJobList);
        setDefaultFilter(false);
    }

    return (
        <>

            <div className={classes.inputgroup}>
                <div className="form-outline">
                    <div className="btn-group">
                        <select className={classes.filters} name="category" id="category" ref={categoryRef}>
                            <option value="Categories">Categories</option>
                            <option value="Accounting">Accounting</option>
                            <option value="Data and Analytics">Data and Analytics</option>
                            <option value="HR">HR</option>
                            <option value="Project Management">Project Management</option>
                            <option value="Sales">Sales</option>
                            <option value="Software Engineer">Software Engineer</option>
                        </select>
                        <select className={classes.filters} name="location" id="location" ref={locationRef}>
                            <option value="Location">Location</option>
                            <option value="Pune">Pune</option>
                            <option value="Bangalore">Bangalore</option>
                            <option value="London">London</option>
                            <option value="Hyderabad">Hyderabad</option>
                            <option value="Gurgaon">Gurgaon</option>
                            <option value="Vancouver">Vancouver</option>
                            <option value="New Delhi">New Delhi</option>
                            <option value="remote">Flexible / Remote</option>
                        </select>
                        <button type="button" onClick={filterHandler} className={classes.btn} >
                            Search
                        </button>
                    </div>
                </div>


            </div>
            {defaultFilter && 
                <Jobs
                isLoading={isFetching}
                loadingText="Fetching Jobs..."
                fallbackText="No jobs rightnow"
                jobList={jobs}
                />
            }
            {!defaultFilter &&
                <Jobs
                isLoading={isFetching}
                loadingText="Fetching Jobs..."
                fallbackText="No jobs rightnow"
                jobList={filteredJobs}
                />

            }
            {/* <Jobs
                isLoading={isFetching}
                loadingText="Fetching Jobs..."
                fallbackText="No jobs rightnow"
                jobList={jobs}
            /> */}

        </>
    );
}