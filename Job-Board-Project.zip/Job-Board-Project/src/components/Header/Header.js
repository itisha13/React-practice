import classes from './Header.module.css';
import { Link } from 'react-router-dom';

export default function Header({heading}) {
    return (
        <>
        <div className={classes.head}>
            {heading}
            <Link to='/admin'><button className={classes.btn} type='button'>ADMIN</button></Link>
        </div>
            {/* <div className={classes.head} class='py-4 bg-dark text-light'>
                Job Board
            </div> */}
        </>
    );
}