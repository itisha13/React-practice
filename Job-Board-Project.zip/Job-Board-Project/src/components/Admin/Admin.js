import classes from './Admin.module.css';
import { useState, useEffect } from 'react';
import { fetchAllJobs } from '../../http';
import { deleteJob } from '../../http';
import { Link } from 'react-router-dom';

export default function Admin() {
    const [jobs, setJobs] = useState([]);
    const [isDeleted, setIsDeleted] = useState(false);
    // const [isFetching, setIsFetching] = useState(false);

    useEffect(() => {

        async function fetchJobs() {
            // setIsFetching(true);
            // const response = await fetch('https://www.themuse.com/api/public/jobs?category=Accounting&category=Data%20and%20Analytics&category=HR&category=Project%20Management&category=Sales&category=Software%20Engineer&location=Bangalore%2C%20India&location=Gurgaon%2C%20India&location=Hyderabad%2C%20India&location=London%2C%20United%20Kingdom&location=New%20Delhi%2C%20India&location=Pune%2C%20India&location=Vancouver%2C%20Canada&page=2');
            // const response = await fetch('http://localhost:8000/jobs');
            // const resData = await response.json();
            const resData = await fetchAllJobs();
            setJobs(resData);
            console.log(resData);
            // console.log(jobs.length);
            // console.log("jobs" + jobs);
            // setIsFetching(false);
        }
        fetchJobs();
    }, []);

    async function deleteHandler(id) {
        const resData = await deleteJob(id);
        setIsDeleted(true);
        console.log(resData);
    }

    return (
        <>

            <div className={classes.head}>
                Admin Panel
            </div>

            <div className={classes.post}>
                <Link to={`/admin/addJob`}><button className={classes.postbtn} type='button'>Post a new Job</button></Link>
                {/* <button className={classes.postbtn} type='button'>Post a new Job</button> */}
            </div>

            {isDeleted && <div>Job Deleted Successfully!</div>}
            {!isDeleted &&
                <div className={classes.container}>
                    {jobs.map((job) => (
                        <div className={classes.jobs}>

                            <p><span><strong>{job.id}</strong></span> <span className={classes.cmp}>{job.company}</span></p>
                            <p>{job.role}</p>
                            <p>{job.category}</p>
                            <p><span>{job.location}</span> | <span>{job.publication_date.slice(0, 10)}</span></p>
                            <button className={classes.delbtn} onClick={() => deleteHandler(job.id)} type='button'>Delete</button>

                        </div>
                    ))}
                </div>
            }

        </>
    )
}