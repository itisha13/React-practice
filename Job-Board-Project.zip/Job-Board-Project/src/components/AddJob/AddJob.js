import { useRef, useState } from "react";
import { addJob } from "../../http";
import classes from './AddJob.module.css';

export default function AddJob() {

    const idRef = useRef();
    const companyRef = useRef();
    const roleRef = useRef();
    const categoryRef = useRef();
    const locationRef = useRef();
    const levelRef = useRef();

    const [isJobAdded, setIsJobAdded] = useState(false);



    const today = new Date();
    const month = today.getMonth() + 1;
    const year = today.getFullYear();
    const date = today.getDate();
    const currentDate = year + "-0" + month + "-" + date;

    async function addHandler() {
        const jobObj = {
            id: idRef.current.value,
            company: companyRef.current.value,
            role: roleRef.current.value,
            category: categoryRef.current.value,
            location: locationRef.current.value,
            publication_date: currentDate,
            level: levelRef.current.value
        }
        const resData = await addJob(jobObj);
        console.log(resData);
        setIsJobAdded(true);
    }

    return (
        <>
            <div className={classes.head}>
                Add Job
            </div>

            {isJobAdded && <div>Job Added Successfully!</div>}
            {!isJobAdded &&
                <div className={classes.outer}>
                    <form className={classes.formclass}>
                        <table>
                            <tr>
                                <td>
                                    <label for='jobId'>Job Id:&nbsp;</label><br />
                                    <input type='text' id='jobId' name='jobId' ref={idRef} /><br /><br />
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <label for='company'>Company Name:&nbsp;</label><br />
                                    <input type='text' id='company' name='company' ref={companyRef} /><br /><br />
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <label for='role'>Role:&nbsp;</label><br />
                                    <input type='text' id='role' name='role' ref={roleRef} /><br /><br />
                                </td>
                            </tr>

                            <tr>
                                <td className={classes.col1}>
                                    <select name="category" id="category" ref={categoryRef}>
                                        <option value="Categories">Categories</option>
                                        <option value="Accounting">Accounting</option>
                                        <option value="Data and Analytics">Data and Analytics</option>
                                        <option value="HR">HR</option>
                                        <option value="Project Management">Project Management</option>
                                        <option value="Sales">Sales</option>
                                        <option value="Software Engineer">Software Engineer</option>
                                    </select>
                                </td>
                                <td className={classes.col2}>
                                    <select name="location" id="location" ref={locationRef}>
                                        <option value="Location">Location</option>
                                        <option value="Pune">Pune</option>
                                        <option value="Bangalore">Bangalore</option>
                                        <option value="London">London</option>
                                        <option value="Hyderabad">Hyderabad</option>
                                        <option value="Gurgaon">Gurgaon</option>
                                        <option value="Vancouver">Vancouver</option>
                                        <option value="New Delhi">New Delhi</option>
                                        <option value="remote">Flexible / Remote</option>
                                    </select>
                                </td>
                                <td className={classes.col3}>
                                    <select name="level" id="level" ref={levelRef}>
                                        <option value="Entry Level">Entry Level</option>
                                        <option value="Mid Level">Mid Level</option>
                                        <option value="Senior Level">Senior Level</option>
                                    </select>
                                </td>

                            </tr>

                            <tr>
                                <td>
                                    <button className={classes.btn} type="button" onClick={addHandler}>ADD</button>
                                </td>
                            </tr>

                        </table>
                    </form>
                </div>
            }

        </>
    );
}