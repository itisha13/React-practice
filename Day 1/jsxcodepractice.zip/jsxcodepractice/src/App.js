import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div>
      <h1>My Favourite foods</h1>
      <ul>
        <li>Pasta</li>
        <li>Pizza</li>
        <li>Noodles</li>
      </ul>
    </div>
  );
}

export default App;
